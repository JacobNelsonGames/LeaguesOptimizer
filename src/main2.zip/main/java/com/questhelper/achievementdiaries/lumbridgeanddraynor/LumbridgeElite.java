/*
 * Copyright (c) 2021, Obasill <https://github.com/Obasill>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.questhelper.achievementdiaries.lumbridgeanddraynor;

import com.questhelper.ItemCollections;
import com.questhelper.QuestHelperQuest;
import com.questhelper.Zone;
import com.questhelper.questhelpers.ComplexStateQuestHelper;
import com.questhelper.requirements.Requirement;
import com.questhelper.requirements.var.ImportantVarplayerRequirement;
import com.questhelper.requirements.ZoneRequirement;
import com.questhelper.requirements.conditional.Conditions;
import com.questhelper.requirements.player.SkillRequirement;
import com.questhelper.requirements.quest.QuestPointRequirement;
import com.questhelper.requirements.quest.QuestRequirement;
import com.questhelper.requirements.util.Operation;
import com.questhelper.requirements.var.VarplayerRequirement;
import com.questhelper.steps.ConditionalStep;
import com.questhelper.steps.EmoteStep;
import com.questhelper.steps.NpcStep;
import com.questhelper.steps.ObjectStep;
import com.questhelper.steps.TileStep;
import com.questhelper.steps.emote.QuestEmote;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import net.runelite.api.ItemID;
import net.runelite.api.NpcID;
import net.runelite.api.ObjectID;
import net.runelite.api.QuestState;
import net.runelite.api.Skill;
import net.runelite.api.coords.WorldPoint;
import com.questhelper.requirements.item.ItemRequirement;
import com.questhelper.QuestDescriptor;
import com.questhelper.panel.PanelDetails;
import com.questhelper.steps.QuestStep;

@QuestDescriptor(
	quest = QuestHelperQuest.LUMBRIDGE_ELITE
)
public class LumbridgeElite extends ComplexStateQuestHelper
{
	@Override
	public int getLPPointDifficultyModifier()
	{
		return 750;
	}

	// Items required
	ItemRequirement lockpick, crossbow, mithgrap, lightsource, axe, addyBar, hammer, ess, waterAccessOrAbyss, qcCape;

	// Items recommended
	ItemRequirement ringOfDueling, dorgSphere;

	Requirement notRichChest, notMovario, notChopMagic, notAddyPlatebody, notWaterRunes, notQCEmote, allQuests,
		deathToDorg, templeOfIkov;

	QuestStep claimReward, richChest, movario, chopMagic, addyPlatebody, waterRunes, qcEmote, moveToWater,
		dorgStairsChest, dorgStairsMovario, moveToOldman, moveToDorgChest, moveToDorgMovario, moveToUndergroundChest,
		moveToUndergroundMovario, moveToDorgAgi;

	ObjectStep moveToDraySewer;

	Zone underground, dorg1, dorg2, draySewer, oldman, waterAltar, dorgAgi;

	ZoneRequirement inUnderground, inDorg1, inDorg2, inDraySewer, inOldman, inWaterAltar, inDorgAgi;

	@Override
	public QuestStep loadStep()
	{
		loadZones();
		setupRequirements();
		setupSteps();

		ConditionalStep doElite = new ConditionalStep(this, claimReward);
		doElite.addStep(new Conditions(notAddyPlatebody, inDraySewer), addyPlatebody);
		doElite.addStep(notAddyPlatebody, moveToDraySewer);
		doElite.addStep(new Conditions(notQCEmote, inOldman), qcEmote);
		doElite.addStep(notQCEmote, moveToOldman);
		doElite.addStep(new Conditions(notRichChest, inDorg2), richChest);
		doElite.addStep(new Conditions(notRichChest, inDorg1), dorgStairsChest);
		doElite.addStep(new Conditions(notRichChest, inUnderground), moveToDorgChest);
		doElite.addStep(notRichChest, moveToUndergroundChest);
		doElite.addStep(new Conditions(notMovario, inDorgAgi), movario);
		doElite.addStep(new Conditions(notMovario, inDorg2), moveToDorgAgi);
		doElite.addStep(new Conditions(notMovario, inDorg1), dorgStairsMovario);
		doElite.addStep(new Conditions(notMovario, inUnderground), moveToDorgMovario);
		doElite.addStep(notMovario, moveToUndergroundMovario);
		doElite.addStep(new Conditions(notWaterRunes, inWaterAltar), waterRunes);
		doElite.addStep(notWaterRunes, moveToWater);
		doElite.addStep(notChopMagic, chopMagic);


		// addy plate, qc emote, water runes, rich chest, movario, chop

		return doElite;
	}

	public void setupRequirements()
	{
		notRichChest = new ImportantVarplayerRequirement(1195, false, 4);
		notMovario = new ImportantVarplayerRequirement(1195, false, 5);
		notChopMagic = new ImportantVarplayerRequirement(1195, false, 6);
		notAddyPlatebody = new ImportantVarplayerRequirement(1195, false, 7);
		notWaterRunes = new ImportantVarplayerRequirement(1195, false, 8);
		notQCEmote = new ImportantVarplayerRequirement(1195, false, 9);

		// todo find better way to check for all quests completed
		allQuests = new QuestPointRequirement(284, Operation.EQUAL);

		lockpick = new ItemRequirement("Lockpick", ItemID.LOCKPICK).showConditioned(notRichChest);
		crossbow = new ItemRequirement("Crossbow", ItemCollections.getCrossbows()).showConditioned(notMovario);
		mithgrap = new ItemRequirement("Mith grapple", ItemID.MITH_GRAPPLE_9419).showConditioned(notMovario);
		lightsource = new ItemRequirement("A lightsource", ItemCollections.getLightSources()).showConditioned(notMovario);
		axe = new ItemRequirement("Any axe", ItemCollections.getAxes()).showConditioned(notChopMagic);
		addyBar = new ItemRequirement("Adamantite bar", ItemID.ADAMANTITE_BAR).showConditioned(notAddyPlatebody);
		hammer = new ItemRequirement("Hammer", ItemID.HAMMER).showConditioned(notAddyPlatebody);
		ess = new ItemRequirement("Essence", ItemCollections.getEssenceLow()).showConditioned(notWaterRunes);
		waterAccessOrAbyss = new ItemRequirement("Access to water altar, or travel through abyss",
			ItemCollections.getWaterAltar()).showConditioned(notWaterRunes);
		qcCape = new ItemRequirement("Quest cape", ItemCollections.getQuestCape()).showConditioned(notQCEmote);
		dorgSphere = new ItemRequirement("Dorgesh-kann Sphere", ItemID.DORGESHKAAN_SPHERE)
			.showConditioned(new Conditions(notMovario, notRichChest));
		ringOfDueling = new ItemRequirement("Ring of dueling", ItemCollections.getRingOfDuelings())
			.showConditioned(notChopMagic);

		inUnderground = new ZoneRequirement(underground);
		inDorg1 = new ZoneRequirement(dorg1);
		inDorg2 = new ZoneRequirement(dorg2);
		inDraySewer = new ZoneRequirement(draySewer);
		inWaterAltar = new ZoneRequirement(waterAltar);
		inOldman = new ZoneRequirement(oldman);
		inDorgAgi = new ZoneRequirement(dorgAgi);

		deathToDorg = new QuestRequirement(QuestHelperQuest.DEATH_TO_THE_DORGESHUUN, QuestState.FINISHED);
		templeOfIkov = new QuestRequirement(QuestHelperQuest.TEMPLE_OF_IKOV, QuestState.FINISHED);
	}

	public void loadZones()
	{
		waterAltar = new Zone(new WorldPoint(2688, 4863, 0), new WorldPoint(2751, 4800, 0));
		underground = new Zone(new WorldPoint(3137, 9706, 0), new WorldPoint(3332, 9465, 2));
		draySewer = new Zone(new WorldPoint(3077, 9699, 0), new WorldPoint(3132, 9641, 0));
		dorg1 = new Zone(new WorldPoint(2688, 5377, 0), new WorldPoint(2751, 5251, 0));
		dorg2 = new Zone(new WorldPoint(2688, 5377, 1), new WorldPoint(2751, 5251, 1));
		oldman = new Zone(new WorldPoint(3087, 3255, 0), new WorldPoint(3094, 3251, 0));
		dorgAgi = new Zone(new WorldPoint(2688, 5247, 0), new WorldPoint(2752, 5183, 3));
	}

	public void setupSteps()
	{
		moveToDraySewer = new ObjectStep(this, ObjectID.TRAPDOOR_6435, new WorldPoint(3118, 3244, 0),
			"Climb down into the Draynor Sewer.");
		moveToDraySewer.addAlternateObjects(ObjectID.TRAPDOOR_6434);
		addyPlatebody = new ObjectStep(this, ObjectID.ANVIL_2097, new WorldPoint(3112, 9689, 0),
			"Smith a adamant platebody at the anvil in Draynor Sewer.", addyBar.quantity(5), hammer);

		moveToOldman = new TileStep(this, new WorldPoint(3088, 3253, 0),
			"Go to the Wise Old Man's house in Draynor Village.");
		qcEmote = new EmoteStep(this, QuestEmote.SKILL_CAPE, new WorldPoint(3088, 3253, 0),
			"Perform the skill cape emote with the quest cape equipped.", qcCape.equipped());

		moveToWater = new ObjectStep(this, 34815, new WorldPoint(3185, 3165, 0),
			"Enter the water altar.", waterAccessOrAbyss.highlighted(), ess.quantity(28));
		waterRunes = new ObjectStep(this, ObjectID.ALTAR_34762, new WorldPoint(2716, 4836, 0),
			"Craft water runes.", ess.quantity(28));

		moveToUndergroundMovario = new ObjectStep(this, ObjectID.TRAPDOOR_14880, new WorldPoint(3209, 3216, 0),
			"Climb down the trapdoor in the Lumbridge Castle.", mithgrap, crossbow, lightsource);
		moveToUndergroundChest = new ObjectStep(this, ObjectID.TRAPDOOR_14880, new WorldPoint(3209, 3216, 0),
			"Climb down the trapdoor in the Lumbridge Castle.", lockpick, lightsource);

		moveToDorgChest = new ObjectStep(this, ObjectID.DOOR_6919, new WorldPoint(3317, 9601, 0),
			"Go through the doors to Dorgesh-Kaan.", lockpick, lightsource);
		moveToDorgMovario = new ObjectStep(this, ObjectID.DOOR_6919, new WorldPoint(3317, 9601, 0),
			"Go through the doors to Dorgesh-Kaan.", mithgrap, crossbow, lightsource);

		dorgStairsMovario = new ObjectStep(this, ObjectID.STAIRS_22939, new WorldPoint(2721, 5360, 0),
			"Climb the stairs to the second level of Dorgesh-Kaan.", mithgrap, crossbow, lightsource);
		dorgStairsChest = new ObjectStep(this, ObjectID.STAIRS_22939, new WorldPoint(2721, 5360, 0),
			"Climb the stairs to the second level of Dorgesh-Kaan.", lockpick);

		richChest = new ObjectStep(this, ObjectID.CHEST_22681, new WorldPoint(2703, 5348, 1),
			"Lockpick the chest.", lockpick);
		moveToDorgAgi = new ObjectStep(this, ObjectID.STAIRS_22941, new WorldPoint(2723, 5253, 1),
			"Climb the stairs to enter the Dorgesh-Kaan agility course.");
		movario = new NpcStep(this, NpcID.MOVARIO, new WorldPoint(2706, 5237, 3),
			"Pickpocket Movario near the end of the agility course.");

		chopMagic = new ObjectStep(this, ObjectID.MAGIC_TREE_10834, new WorldPoint(3357, 3312, 0),
			"Chop some magic logs near the Magic Training Arena.", axe);

		claimReward = new NpcStep(this, NpcID.HATIUS_COSAINTUS, new WorldPoint(3235, 3213, 0),
			"Talk to Hatius Cosaintus in Lumbridge to claim your reward!");
		claimReward.addDialogStep("I have a question about my Achievement Diary.");
	}

	@Override
	public List<ItemRequirement> getItemRequirements()
	{
		return Arrays.asList(qcCape, lockpick, mithgrap, hammer, waterAccessOrAbyss, axe, addyBar.quantity(5),
			ess.quantity(28), crossbow);
	}

	@Override
	public List<ItemRequirement> getItemRecommended()
	{
		return Arrays.asList(ringOfDueling, dorgSphere);
	}

	@Override
	public List<Requirement> getGeneralRequirements()
	{
		List<Requirement> reqs = new ArrayList<>();
		//keep this up to date
		reqs.add(new QuestPointRequirement(284));
		reqs.add(new SkillRequirement(Skill.AGILITY, 70));
		reqs.add(new SkillRequirement(Skill.RANGED, 70));
		reqs.add(new SkillRequirement(Skill.RUNECRAFT, 76));
		reqs.add(new SkillRequirement(Skill.SMITHING, 88));
		reqs.add(new SkillRequirement(Skill.STRENGTH, 70));
		reqs.add(new SkillRequirement(Skill.THIEVING, 78));
		reqs.add(new SkillRequirement(Skill.WOODCUTTING, 75));

		reqs.add(allQuests);

		return reqs;
	}

	@Override
	public List<PanelDetails> getPanels()
	{
		List<PanelDetails> allSteps = new ArrayList<>();

		// addy plate, qc emote, water runes, rich chest, movario, chop

		PanelDetails adamantitePlatebodySteps = new PanelDetails("Adamantite Platebody",
			Arrays.asList(moveToDraySewer, addyPlatebody), new SkillRequirement(Skill.SMITHING, 88),
			addyBar.quantity(5), hammer);
		adamantitePlatebodySteps.setDisplayCondition(notAddyPlatebody);
		allSteps.add(adamantitePlatebodySteps);

		PanelDetails questCapeEmoteSteps = new PanelDetails("Quest Cape Emote", Arrays.asList(moveToOldman, qcEmote),
			allQuests, qcCape);
		questCapeEmoteSteps.setDisplayCondition(notQCEmote);
		allSteps.add(questCapeEmoteSteps);

		PanelDetails waterRunesSteps = new PanelDetails("140 Water Runes", Arrays.asList(moveToWater, waterRunes),
			new SkillRequirement(Skill.RUNECRAFT, 76), ess.quantity(28), waterAccessOrAbyss);
		waterRunesSteps.setDisplayCondition(notWaterRunes);
		allSteps.add(waterRunesSteps);

		PanelDetails richChestSteps = new PanelDetails("Dorgesh-Kaan Rich Chest", Arrays.asList(moveToUndergroundChest,
			moveToDorgChest, dorgStairsChest, richChest), new SkillRequirement(Skill.THIEVING, 78), deathToDorg, lightsource,
			lockpick);
		richChestSteps.setDisplayCondition(notRichChest);
		allSteps.add(richChestSteps);

		PanelDetails movarioSteps = new PanelDetails("Movario", Arrays.asList(moveToUndergroundMovario, moveToDorgMovario,
			dorgStairsMovario, moveToDorgAgi, movario), new SkillRequirement(Skill.THIEVING, 42),
			new SkillRequirement(Skill.AGILITY, 70), new SkillRequirement(Skill.RANGED, 70),
			new SkillRequirement(Skill.STRENGTH, 70), deathToDorg, templeOfIkov, mithgrap, crossbow, lightsource);
		movarioSteps.setDisplayCondition(notMovario);
		allSteps.add(movarioSteps);

		PanelDetails chopMagicsSteps = new PanelDetails("Chop Magics", Collections.singletonList(chopMagic),
			new SkillRequirement(Skill.WOODCUTTING, 75), axe);
		chopMagicsSteps.setDisplayCondition(notChopMagic);
		allSteps.add(chopMagicsSteps);

		return allSteps;
	}
}
