package shortestpath;

import com.questhelper.questhelpers.ActionHelper;
import net.runelite.client.ui.overlay.worldmap.WorldMapPoint;

import java.awt.*;

public class WorldMapActionInfo
{
    public boolean Enabled = true;
    public WorldMapPoint marker;
    public Color markercolor;
    public ActionHelper AssociatedAction;
}
